from app import app
from flask import Flask, render_template
import pandas as pd
# import sys

@app.route('/')
def home1():
    return "hello world"


@app.route('/csv')
def read_csv_to_html():
    file_name = 'titanic'
    data = pd.read_csv('app/' + file_name + ".csv")
    data.to_html("app/templates/" + file_name + ".html")

    return render_template(file_name + ".html")

@app.route('/csv2')
def read_csv_to_html2():
    my_file = open('app/titanic.csv', 'r')
    data = my_file.read()
    print(data)
    return render_template('home.html', data = data)
  